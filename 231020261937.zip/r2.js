const MAX_ITEMS_IN_BOX = 60;
let selectedBoxId = null;
let currentBoxMode = 'normal'; // 'normal' (Товары) или 'defective' (Брак)

// Переменные для флоу добавления
let tempItemToAdd = null;
let currentDefectPhotos = []; // Хранит base64 строк изображений (макс 4)

// --- Helper Functions ---
function playSuccessSound() { 
    const successSound = document.getElementById('success-sound');
    if (successSound) { 
        successSound.currentTime = 0;
        successSound.play().catch(e => console.error("Success sound play failed:", e)); 
    } 
}

function playScannerSound() {
    const scannerSound = document.getElementById('scanner-sound');
    if (scannerSound) {
        scannerSound.currentTime = 0;
        scannerSound.play().catch(e => {});
    }
}

// Воспроизведение одного звука
function playSingleSound(id) {
    const audio = document.getElementById(id);
    if (audio) {
        audio.currentTime = 0;
        audio.play().catch(e => console.error("Sound play failed:", e));
    }
}

// Последовательное воспроизведение звуков ошибок (сначала failScan, потом голосовой маркер)
function playTwoSounds(firstId, secondId) {
    const first = document.getElementById(firstId);
    const second = document.getElementById(secondId);
    if (first && second) {
        first.currentTime = 0;
        first.play().catch(e => console.error("First sound play failed:", e));
        first.onended = () => {
            second.currentTime = 0;
            second.play().catch(e => console.error("Second sound play failed:", e));
            first.onended = null;
        };
    } else if (second) {
        playSingleSound(secondId);
    }
}

function copyBoxId(id) {
    navigator.clipboard.writeText(id).then(() => {
        showAlert('ШК скопирован', false);
    }).catch(err => {
        console.error('Не удалось скопировать текст: ', err);
    });
}

// --- Initialization ---
function initVozvratKorobkiPage () {
    // Имитация загрузки
    setTimeout(() => {
        const loader = document.getElementById('data-loader');
        if(loader) loader.style.display = 'none';
    }, 2000);

    cleanupClosedBoxes(); 
    setupTabs();
    renderBoxStrip();
    toggleMainSplit(false); // Скрыть по умолчанию
    
    // Create Box Events
    const submitBoxBtn = document.getElementById('submit-new-box-btn');
    if(submitBoxBtn) submitBoxBtn.addEventListener('click', createBox);
    
    const boxInput = document.getElementById('new-box-code');
    if (boxInput) {
        boxInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') createBox();
        });
    }
    
    const closeBoxModalBtn = document.getElementById('close-create-box-modal');
    if(closeBoxModalBtn) closeBoxModalBtn.addEventListener('click', () => toggleModal('create-box-modal', false));

    // Нажатие на "Вернуться к открытой коробке" (теперь закрывает интегрированное вью)
    const backBtn = document.getElementById('close-normal-return-btn');
    if (backBtn) backBtn.addEventListener('click', () => toggleNormalReturnView(false));

    // Search/Add Item Events
    const searchInput = document.getElementById('return-item-search');
    const addItemBtn = document.getElementById('add-item-to-box-btn');
    
    if(addItemBtn) addItemBtn.addEventListener('click', () => handleSearchInput(searchInput.value));
    if(searchInput) searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') handleSearchInput(searchInput.value);
    });

    // Close Modals logic
    document.querySelectorAll('.close-modal-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const modal = e.target.closest('.fullscreen-modal');
            if(modal) toggleModal(modal.id, false);
        });
    });

    // Ввод стикера с клавиатуры (по Enter)
    const stickerInput = document.getElementById('normal-return-sticker-input');
    if (stickerInput) {
        stickerInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') confirmNormalReturn();
        });
    }

    // --- Defective Flow Setup ---
    const goToDefectBtn = document.getElementById('go-to-defective-form-btn');
    if(goToDefectBtn) goToDefectBtn.addEventListener('click', () => {
        toggleModal('defective-warning-modal', false);
        openDefectiveFormModal();
    });

    const reasonSelect = document.getElementById('defective-reason-select');
    if(reasonSelect) {
        reasonSelect.addEventListener('change', (e) => {
            const otherInput = document.getElementById('defective-reason-other-input');
            if(otherInput) otherInput.style.display = e.target.value === 'Другое' ? 'block' : 'none';
        });
    }

    // Photo Upload Logic
    const addPhotoBtn = document.getElementById('add-photo-btn');
    if(addPhotoBtn) addPhotoBtn.addEventListener('click', () => {
        const fileInput = document.getElementById('photo-input-hidden');
        if(fileInput) fileInput.click();
    });

    const photoInput = document.getElementById('photo-input-hidden');
    if(photoInput) photoInput.addEventListener('change', handlePhotoSelection);
    
    const submitDefectBtn = document.getElementById('submit-defective-full-btn');
    if(submitDefectBtn) submitDefectBtn.addEventListener('click', submitDefectiveForm);

    // Global Scan Listener
    document.addEventListener('scan', (e) => {
        const code = e.detail.code;
        
        // Если открыто новое вью нормального возврата -> ввод стикера
        const normalReturnView = document.getElementById('normal-return-view');
        if (normalReturnView && normalReturnView.style.display !== 'none') {
            const stkInput = document.getElementById('normal-return-sticker-input');
            if(stkInput) stkInput.value = code;
            playScannerSound();
            confirmNormalReturn();
            return;
        }

        // Если открыта модалка создания коробки
        if (document.getElementById('create-box-modal').classList.contains('visible')) {
             const nBoxInput = document.getElementById('new-box-code');
             if(nBoxInput) nBoxInput.value = code;
             createBox();
             return;
        }

        // Если коробка выбрана и нет модалок -> поиск
        if (selectedBoxId) {
            const anyModalVisible = document.querySelector('.fullscreen-modal.visible');
            if (!anyModalVisible) {
                const sInput = document.getElementById('return-item-search');
                if(sInput) {
                    sInput.value = code;
                    handleSearchInput(code);
                }
            }
        }
    });
}

function cleanupClosedBoxes() {
    const userData = getUserData();
    let boxes = userData.returnBoxes || [];
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);

    const initialLength = boxes.length;
    boxes = boxes.filter(box => {
        if (!box.isClosed) return true;
        if (!box.closedAt) return false; 
        const closedDate = new Date(box.closedAt);
        closedDate.setHours(0, 0, 0, 0);
        return closedDate.getTime() === todayStart.getTime();
    });

    if (boxes.length !== initialLength) {
        userData.returnBoxes = boxes;
        saveUserData(userData);
    }
}

// --- UI: Tabs & Modes ---
function setupTabs() {
    const tabNormal = document.getElementById('tab-normal');
    const tabDefective = document.getElementById('tab-defective');
    if(tabNormal) tabNormal.addEventListener('click', () => switchMode('normal'));
    if(tabDefective) tabDefective.addEventListener('click', () => switchMode('defective'));
}

function switchMode(mode) {
    currentBoxMode = mode;
    selectedBoxId = null;
    toggleMainSplit(false);
    toggleNormalReturnView(false); // Сбрасываем вью оформления при смене таба
    
    document.querySelectorAll('.box-tab-btn').forEach(btn => btn.classList.remove('active'));
    const activeTab = document.getElementById(`tab-${mode}`);
    if(activeTab) activeTab.classList.add('active');

    renderBoxStrip();
}

function toggleMainSplit(visible) {
    const split = document.getElementById('box-main-split');
    const placeholder = document.getElementById('no-box-selected-placeholder');
    if (split && placeholder) {
        if (visible) {
            split.style.display = 'flex';
            placeholder.style.display = 'none';
        } else {
            split.style.display = 'none';
            placeholder.style.display = 'flex';
        }
    }
}

// Переключение видимости вью оформления (замена старой модалке)
function toggleNormalReturnView(visible) {
    const workspace = document.querySelector('.box-workspace-layout');
    const returnView = document.getElementById('normal-return-view');
    
    if (!workspace || !returnView) return;

    if (visible) {
        workspace.style.display = 'none';
        returnView.style.display = 'flex';
    } else {
        workspace.style.display = ''; // Сброс к дефолту из CSS
        returnView.style.display = 'none';
    }
}

// --- Box Management ---
function showCreateBoxModal() {
    const title = document.getElementById('create-box-title');
    const input = document.getElementById('new-box-code');
    if(input) input.value = '';
    
    if(title) {
        title.textContent = currentBoxMode === 'defective' ? 'Отсканируйте стикер коробки' : 'Отсканируйте стикер коробки'; 
    }
    
    toggleModal('create-box-modal', true);
    
    playSingleSound('sound-scan-box');
    
    if(input) setTimeout(() => input.focus(), 100);
}

function createBox() {
    const input = document.getElementById('new-box-code');
    const code = input.value.trim();
    
    if (!/^\d{10}$/.test(code)) {
        playTwoSounds('sound-fail', 'sound-incorrect-sticker');
        showAlert('Некорректный стикер', true); 
        return;
    }
    
    const userData = getUserData();
    let boxes = userData.returnBoxes || [];
    
    if (boxes.some(box => box.id === code)) {
        playTwoSounds('sound-fail', 'sound-box-exists');
        showAlert('Коробка уже принята', true);
        return;
    }
    
    const newBox = { 
        id: code, 
        createdAt: new Date().toISOString(), 
        closedAt: null, 
        items: [], 
        isClosed: false,
        type: currentBoxMode 
    };
    boxes.unshift(newBox);
    userData.returnBoxes = boxes;
    saveUserData(userData);
    
    toggleModal('create-box-modal', false);
    renderBoxStrip();
    selectBox(code);
    showAlert(`Коробка ${code} создана`, false);
}

function renderBoxStrip() {
    const container = document.getElementById('box-strip-container');
    if(!container) return;
    container.innerHTML = '';

    const userData = getUserData();
    let boxes = userData.returnBoxes || [];

    const filteredBoxes = boxes.filter(b => {
        const type = b.type || 'normal';
        return type === currentBoxMode;
    });

    const openBoxes = filteredBoxes.filter(b => !b.isClosed);
    const closedBoxes = filteredBoxes.filter(b => b.isClosed);

    // 1. Create Button
    const createBtn = document.createElement('div');
    createBtn.className = `box-strip-item-new create-btn`;
    createBtn.onclick = showCreateBoxModal;
    createBtn.innerHTML = `
        <i class="fas fa-plus" style="font-size: 24px; color: #000;"></i>
        <div style="margin-top: 8px; font-weight: bold; color: #000; font-size: 1.1em;">Создать</div>
    `;
    container.appendChild(createBtn);

    // 2. Open Boxes
    openBoxes.forEach(box => container.appendChild(createBoxStripElement(box)));

    // 3. Closed Boxes
    closedBoxes.forEach(box => container.appendChild(createBoxStripElement(box)));
}

function createBoxStripElement(box) {
    const el = document.createElement('div');
    el.className = `box-strip-item-new ${box.isClosed ? 'closed' : 'open'}`;
    
    if (box.id === selectedBoxId) {
        el.style.boxShadow = '0 0 0 4px rgba(168, 85, 247, 0.4)';
    }
    
    el.innerHTML = `
        <div style="text-align: left; margin-right: 25px;">
            <div style="font-size: 0.9em; font-weight: 500; margin-bottom: 4px; color: #000;">Коробка</div>
            <div style="font-weight: bold; font-size: 1.2em; color: #000;">${box.id}</div>
        </div>
        <img src="copy.svg" class="copy-btn-svg" onclick="event.stopPropagation(); copyBoxId('${box.id}')" title="Скопировать ШК">
    `;
    el.onclick = () => selectBox(box.id);
    return el;
}

// Выбор активной коробки
function selectBox(boxId) {
    selectedBoxId = boxId;
    renderBoxStrip(); 
    toggleMainSplit(true);
    renderBoxDetails(boxId);
}

function downloadSticker(boxId) {
    const qrModal = document.getElementById('qr-code-modal');
    if (qrModal) {
        qrModal.innerHTML = `
            <div class="modal-content" style="text-align: center;">
                <button class="close-modal-btn" onclick="toggleModal('qr-code-modal', false)">&times;</button>
                <h2>Наклейка для коробки</h2>
                <div style="margin: 20px auto; padding: 20px; background: white; display: inline-block;">
                    <div style="width:250px; height:250px; border:2px dashed #6b21a8; display:flex; flex-direction:column; align-items:center; justify-content:center; background:#f3e8ff;">
                        <span style="font-size:1.2em; font-weight:bold; color:#6b21a8; margin-bottom: 10px;">QR CODE</span>
                        <span style="color:#555;">TRBX${boxId}</span>
                    </div>
                </div>
                <p style="font-size: 1.8em; font-weight: bold; margin-top: 10px;">${boxId}</p>
            </div>
        `;
        toggleModal('qr-code-modal', true);
    } else {
        alert(`TRBX${boxId} - ${boxId}`);
    }
}

function renderBoxDetails(boxId) {
    const userData = getUserData();
    const boxes = userData.returnBoxes || [];
    const box = boxes.find(b => b.id === boxId);
    if (!box) return;

    const detailsPanel = document.getElementById('box-details-panel');
    const contentContainer = document.getElementById('box-items-container');
    const searchContainer = document.getElementById('return-item-search-container');

    if(searchContainer) searchContainer.style.display = box.isClosed ? 'none' : 'flex';

    const closeBtnHTML = !box.isClosed 
        ? `<button class="primary-btn box-close-action-btn" onclick="closeBox('${box.id}')" style="margin-bottom: 10px; width: 100%;">Закрыть коробку</button>` 
        : '';

    const iconSrc = box.isClosed ? "box.svg" : "open-box.svg";

    if(detailsPanel) {
        detailsPanel.innerHTML = `
            <div class="bd-top-right">
                <div class="bd-small-label">Коробка</div>
                <div class="bd-large-id">${box.id}</div>
            </div>
            
            <div class="bd-divider"></div>
            
            <div class="bd-icons">
                <img src="${iconSrc}" style="width: 24px; height: 24px;" alt="статус">
            </div>
            
            <div class="bd-occupancy-banner">
                <div style="color: #666; font-size: 0.9em; margin-bottom: 5px;">Занятость</div>
                <div class="bd-occupancy-val">${(box.items || []).length} / ${MAX_ITEMS_IN_BOX}</div>
            </div>
            
            <div style="flex-grow: 1;"></div>
            
            ${closeBtnHTML}
            <button class="download-sticker-btn" onclick="downloadSticker('${box.id}')">Скачать наклейку</button>
        `;
    }

    // Рендерим правую область
    if(contentContainer) {
        if (box.items && box.items.length > 0) {
            contentContainer.innerHTML = box.items.map(item => createBoxItemCard(item)).join('');
            contentContainer.style.display = 'grid';
        } else {
            contentContainer.style.display = 'block';
            contentContainer.innerHTML = `
                <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100%; min-height: 300px; color: #888;">
                    <img src="marketplace_box.png" alt="Пустая коробка" style="width: 120px; margin-bottom: 20px;">
                    <h2 style="color: #333; margin-bottom: 10px;">Коробка пуста.</h2>
                    <p>Отсканируйте товары для возврата.</p>
                </div>
            `;
        }
    }
}

function createBoxItemCard(item) {
    const imageContent = item.isAdult 
        ? `<img src="adult.svg" style="width:100%; height:100%; object-fit:contain;">` 
        : (item.image ? `<img src="${item.image}" style="width:100%; height:100%; object-fit:contain;">` : '📦');
    const code = item.newCode || item.code;

    return `
        <div class="product-card vertical box-item-card">
            ${item.isDefective ? '<div class="defective-ribbon"><span>БРАК</span></div>' : ''}
            <div class="vertical-img-container" style="height: 120px;">
                 ${imageContent}
            </div>
            <div class="vertical-info">
                 <div class="v-code-row">${code}</div>
                 <div class="v-name-row" style="-webkit-line-clamp: 2;">${item.name || 'Товар'}</div>
            </div>
        </div>
    `;
}

function closeBox(boxId) {
    if (!confirm(`Закрыть коробку ${boxId}?`)) return;
    const userData = getUserData();
    let boxes = userData.returnBoxes;
    const idx = boxes.findIndex(b => b.id === boxId);
    if (idx > -1) {
        boxes[idx].isClosed = true;
        boxes[idx].closedAt = new Date().toISOString();
        userData.returnBoxes = boxes;
        saveUserData(userData);
        
        playSingleSound('sound-box-closed');
        
        renderBoxStrip();
        renderBoxDetails(boxId);
    }
}

// --- MAIN SEARCH & ADD LOGIC ---
function handleSearchInput(val) {
    if (!selectedBoxId) { showAlert('Сначала выберите коробку', true); return; }
    
    const code = val.trim();
    if (!/^\d{10}$/.test(code)) { showAlert('Введите 10 цифр', true); return; }

    const userData = getUserData();
    const allReturns = userData.returnsItems || [];

    const targetItem = allReturns.find(item => {
        const notConfirmed = !item.confirmed;
        const matchesMode = currentBoxMode === 'defective' ? item.isDefective : !item.isDefective;
        return notConfirmed && matchesMode;
    });

    if (!targetItem) {
        if (currentBoxMode === 'defective') {
            showAlert('Нет товаров для брака', true);
        } else {
            showAlert('Нет доступных товаров для возврата', true);
        }
        return;
    }

    tempItemToAdd = targetItem; 
    playScannerSound();
    
    const searchInput = document.getElementById('return-item-search');
    if(searchInput) searchInput.value = '';

    if (currentBoxMode === 'defective') {
        openDefectiveWarningModal(targetItem);
    } else {
        openNormalReturnModal(targetItem);
    }
}

// --- NORMAL FLOW ---
function openNormalReturnModal(item) {
    const cardPreview = document.getElementById('normal-return-card-preview');
    if(cardPreview) {
        cardPreview.innerHTML = `
            <div style="background: #f9f9f9; padding: 20px; border-radius: 12px; height: 100%;">
                ${createBoxItemCard(item)}
            </div>
        `;
    }

    const noPkgRadio = document.querySelector('input[name="safe-pkg"][value="Пакет не нужен"]');
    if(noPkgRadio) noPkgRadio.checked = true;
    
    const input = document.getElementById('normal-return-sticker-input');
    if(input) input.value = '';
    
    toggleNormalReturnView(true); // Запуск интегрированного вью
    if(input) setTimeout(() => input.focus(), 100);
}

function confirmNormalReturn() {
    if (!tempItemToAdd) { showAlert('Ошибка: товар не выбран', true); return; }

    const stickerInput = document.getElementById('normal-return-sticker-input');
    const newCode = stickerInput.value.trim();
    
    if (!/^\d{10}$/.test(newCode)) {
        showAlert('Введите корректный стикер', true);
        return;
    }

    const safePkgEl = document.querySelector('input[name="safe-pkg"]:checked');
    const safePkg = safePkgEl ? safePkgEl.value : 'Нет';
    
    finishAddItem(tempItemToAdd, newCode, safePkg);
    toggleNormalReturnView(false); // Скрытие вью
}

// --- DEFECTIVE FLOW ---
function openDefectiveWarningModal(item) {
    const preview = document.getElementById('defective-warning-preview');
    if(preview) preview.innerHTML = createBoxItemCard(item);
    
    playSingleSound('sound-defect-mark');
    
    toggleModal('defective-warning-modal', true);
}

function openDefectiveFormModal() {
    const select = document.getElementById('defective-reason-select');
    if(select) {
        select.innerHTML = '<option value="">Выберите причину</option>';
        const reasons = [
            "Биологические пятна", "Вещи из разных комплектов", "Дефект ткани", "Дефект швов", 
            "Деформация/Вмятины", "Дыры", "Загрязнения", "Залито", "Запайка", 
            "Испорчено грызунами", "Косметические пятна", "Маркер/ручка", "Недокомплект", 
            "Некачественная фурнитура", "Неполный набор", "Отклонения в размерах", 
            "Отсутствие аксессуара/декора", "Отсутствие русскоязычной маркировки", 
            "Перекос и натяжение", "Подмена", "Порез", "Потёртости/царапины", "Пыль/грязь", 
            "Разнопарка", "Разрежение ткани", "Разрыв строчки в ткани", "Разрыв шва", 
            "Следы разметки", "Упаковка - неотъемлемая часть товара, нарушена", 
            "Химические пятна", "Цвет и структура", "Другое"
        ];
        reasons.forEach(r => {
            const opt = document.createElement('option');
            opt.value = r; opt.textContent = r;
            select.appendChild(opt);
        });
    }
    
    const otherInput = document.getElementById('defective-reason-other-input');
    if(otherInput) {
        otherInput.style.display = 'none';
        otherInput.value = '';
    }
    
    const commentInput = document.getElementById('defective-comment');
    if (commentInput) {
        commentInput.value = '';
    }

    currentDefectPhotos = [];
    renderPhotoGrid();

    toggleModal('defective-form-modal', true);
}

function handlePhotoSelection(e) {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    if (currentDefectPhotos.length + files.length > 4) {
        showAlert("Максимум 4 фото", true);
        return;
    }

    files.forEach(file => {
        const reader = new FileReader();
        reader.onload = (ev) => {
            currentDefectPhotos.push(ev.target.result);
            renderPhotoGrid();
        };
        reader.readAsDataURL(file);
    });
    e.target.value = '';
}

function renderPhotoGrid() {
    for (let i = 0; i < 4; i++) {
        const slot = document.getElementById(`p-slot-${i}`);
        if(slot) {
            slot.innerHTML = '';
            if (currentDefectPhotos[i]) {
                const img = document.createElement('img');
                img.src = currentDefectPhotos[i];
                img.onclick = () => openImageViewer(currentDefectPhotos[i]);
                slot.appendChild(img);
                slot.classList.add('filled');
            } else {
                slot.classList.remove('filled');
            }
        }
    }
}

function openImageViewer(src) {
    const img = document.getElementById('full-screen-image');
    if(img) {
        img.src = src;
        toggleModal('image-viewer-modal', true);
    }
}

function submitDefectiveForm() {
    if (!tempItemToAdd) { showAlert('Товар не выбран', true); return; }

    const select = document.getElementById('defective-reason-select');
    let reason = select.value;
    if (!reason) { showAlert("Выберите причину", true); return; }
    
    if (reason === 'Другое') {
        const otherVal = document.getElementById('defective-reason-other-input').value.trim();
        if (!otherVal) { showAlert("Укажите причину", true); return; }
        reason = otherVal;
    }

    if (currentDefectPhotos.length < 4) {
        showAlert("Необходимо 4 фотографии", true);
        return;
    }

    // Проверка обязательного комментария
    const commentVal = document.getElementById('defective-comment').value.trim();
    if (!commentVal) {
        showAlert("Добавьте комментарий к браку (обязательно)", true);
        return;
    }

    const photosPlaceholder = [
        "Фото 1 загружено", 
        "Фото 2 загружено", 
        "Фото 3 загружено", 
        "Фото 4 загружено"
    ];

    const defectInfo = {
        reason: reason,
        comment: commentVal,
        photos: photosPlaceholder
    };

    tempItemToAdd.defectiveInfo = defectInfo;
    finishAddItem(tempItemToAdd, tempItemToAdd.code, 'Без пакета'); 
    toggleModal('defective-form-modal', false);
}

// --- SHARED ADD LOGIC ---
function finishAddItem(item, newCode, safePkg) {
    const userData = getUserData();
    let boxes = userData.returnBoxes || [];

    const boxIdx = boxes.findIndex(b => b.id === selectedBoxId);

    if (boxIdx === -1) { 
        showAlert('Коробка не найдена', true);
        return; 
    }
    
    if (!boxes[boxIdx].items) {
        boxes[boxIdx].items = [];
    }

    if (boxes[boxIdx].items.length >= MAX_ITEMS_IN_BOX) { 
        showAlert('Коробка полная. Закройте коробку!', true);
        return; 
    }

    const itemToAdd = {
        ...item,
        newCode: newCode,
        safePackage: safePkg,
        confirmed: true,
        placedInBoxId: selectedBoxId
    };

    boxes[boxIdx].items.unshift(itemToAdd);
    userData.returnBoxes = boxes; 

    const returns = userData.returnsItems || [];
    const originalItemIdx = returns.findIndex(i => i.code === item.code && !i.confirmed);

    if (originalItemIdx > -1) {
        returns[originalItemIdx].confirmed = true;
        if (item.defectiveInfo) {
            returns[originalItemIdx].defectiveInfo = item.defectiveInfo;
        }
    } else {
        const fallbackIdx = returns.findIndex(i => i.code === item.code);
        if(fallbackIdx > -1) returns[fallbackIdx].confirmed = true;
    }
    
    userData.returnsItems = returns;

    saveUserData(userData);
    playSuccessSound();
    
    renderBoxDetails(selectedBoxId);
    showAlert('Товар добавлен', false);
    
    tempItemToAdd = null;
}

// Вызов инициализации при загрузке (если не вызывается в другом скрипте)
window.onload = function() {
    initVozvratKorobkiPage();
};