// Глобальные переменные для состояний многошаговой авторизации
window.currentLoginId = null;
window.phoneData = null;
window.isLegacyOwner = false;
window.isSettingPassword = false;

// Глобальные переменные для работы с ПИН-кодом
window.currentOwnerUid = null;
window.currentPvzId = null;
window.currentSelectedEmp = null;
window.currentEmpPin = null;
window.pinMode = 'enter'; // 'enter', 'setup', 'reset'
window.resettingPinForEmpId = null;
window.enteredPassword = null; // Запоминаем введенный в шаге 2 пароль аккаунта для подтверждения ПИН-кода

document.addEventListener('DOMContentLoaded', () => {
    const isLoginPage = !!document.getElementById('next-phone-btn');
    const isRegisterPage = !!document.getElementById('register-btn');

    // Настройка кнопок скрытия/показа паролей
    document.querySelectorAll('.password-group').forEach(group => {
        const toggleBtn = group.querySelector('.password-toggle');
        const passwordInput = group.querySelector('input[type="password"]');
        if(toggleBtn && passwordInput) {
            toggleBtn.addEventListener('click', () => {
                const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordInput.setAttribute('type', type);
                toggleBtn.innerHTML = type === 'password' ? '<i class="fas fa-eye"></i>' : '<i class="fas fa-eye-slash"></i>';
            });
        }
    });

    if (isLoginPage) {
        initCountrySelector('login-phone-wrapper');

        // Обработчики шагов авторизации
        document.getElementById('next-phone-btn').addEventListener('click', handlePhoneNext);
        document.getElementById('login-id').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') handlePhoneNext();
        });

        document.getElementById('back-to-phone-btn').addEventListener('click', () => {
            document.getElementById('step-password').style.display = 'none';
            document.getElementById('step-phone').style.display = 'block';
            document.getElementById('login-password').value = '';
            document.getElementById('login-password-confirm').value = '';
        });

        document.getElementById('login-btn').addEventListener('click', handlePasswordSubmit);
        document.getElementById('login-password').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') handlePasswordSubmit();
        });

        // --- Обработчики экрана ПИН КОДА ---
        document.getElementById('pin-submit-btn').addEventListener('click', submitPin);
        document.getElementById('pin-input').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') submitPin();
        });
        document.getElementById('forgot-pin-link').addEventListener('click', handleForgotPin);
        document.getElementById('back-to-managers-btn').addEventListener('click', () => {
            document.getElementById('pin-screen').style.display = 'none';
            document.getElementById('manager-selection-screen').style.display = 'block';
            window.resettingPinForEmpId = null;
        });

        document.getElementById('forgot-password-link').addEventListener('click', (e) => {
            e.preventDefault();
            document.getElementById('recovery-step1').style.display = 'block';
            document.getElementById('recovery-step2').style.display = 'none';
            document.getElementById('recovery-email').value = '';
            toggleModal('recovery-modal', true);
        });
        
        document.getElementById('check-recovery-email-btn').addEventListener('click', handleCheckRecoveryEmail);
        document.getElementById('recovery-confirm-yes').addEventListener('click', sendRecoveryLink);
        document.getElementById('recovery-confirm-no').addEventListener('click', () => {
            toggleModal('recovery-modal', false);
        });
        
        document.querySelector('#recovery-modal .close-modal-btn')?.addEventListener('click', () => {
             toggleModal('recovery-modal', false);
        });

        document.getElementById('pvz-not-found-btn')?.addEventListener('click', () => {
             alert("Извините за временное неудобство! Возможно мы не активировали ваш ПВЗ в системе Wildberries, если ПВЗ не появится в течении 15 минут, сообщите об этом нам на сайте pvz.wb.ru в разделе помощник!");
        });

        // Авто-авторизация (старая сессия Firebase или новая сессия сотрудника)
        firebase.auth().onAuthStateChanged(async user => {
            if (user && window.location.pathname.includes('login.html')) {
                checkSavedSessionsAndRedirect(user.uid);
            }
        });
        
        const empPhoneSession = localStorage.getItem('employeePhone') || sessionStorage.getItem('employeePhone');
        if (!firebase.auth().currentUser && empPhoneSession) {
             checkSavedSessionsAndRedirect(null);
        }

    } else if (isRegisterPage) {
        initCountrySelector('reg-phone-wrapper');
        initCountrySelector('owner-phone-wrapper');
        setupRegisterLogic();
    }
});

async function checkSavedSessionsAndRedirect(ownerUid) {
    const hasPvz = localStorage.getItem('savedPvzId');
    const savedOwner = localStorage.getItem('savedOwnerUid') || ownerUid;
    const hasManager = sessionStorage.getItem('currentManager');

    if (hasPvz && hasManager) {
        window.location.href = 'index.html';
    } else if (hasPvz && savedOwner && !hasManager) {
        // FAST LOGIN: Переходим к списку менеджеров, минуя ввод телефона и пароля
        document.getElementById('main-auth-form').style.display = 'none';
        loadEmployeesForFastLogin(savedOwner, hasPvz);
    } else if (ownerUid) {
        document.getElementById('main-auth-form').style.display = 'none';
        const pvzSnap = await firebase.database().ref('users/' + ownerUid + '/pvzInfo').once('value');
        showPvzSelectionScreen(pvzSnap.val());
    }
}

function initCountrySelector(wrapperId) {
    const wrapper = document.getElementById(wrapperId);
    if (!wrapper) return;
    
    const selector = wrapper.querySelector('.custom-country-selector');
    const selectedFlag = wrapper.querySelector('.flag-img');
    const list = wrapper.querySelector('.country-dropdown-list');
    const prefixSpan = wrapper.querySelector('.phone-prefix');
    const phoneInput = wrapper.querySelector('.phone-input');

    phoneInput.dataset.countryCode = '7'; 
    phoneInput.maxLength = 10;

    selector.addEventListener('click', (e) => {
        list.classList.toggle('show');
        e.stopPropagation();
    });

    document.addEventListener('click', () => {
        list.classList.remove('show');
    });

    list.querySelectorAll('li').forEach(item => {
        item.addEventListener('click', (e) => {
            e.stopPropagation();
            const code = item.getAttribute('data-code');
            const prefix = item.getAttribute('data-prefix');
            const length = item.getAttribute('data-length');
            const imgSrc = item.getAttribute('data-img');

            phoneInput.dataset.countryCode = code;
            selectedFlag.src = imgSrc;
            prefixSpan.textContent = prefix;
            if(length) phoneInput.maxLength = length;
            phoneInput.value = '';
            phoneInput.focus();

            list.classList.remove('show');
        });
    });
}

// ШАГ 1: Проверка номера телефона в БД
async function handlePhoneNext() {
    const phoneInputEl = document.getElementById('login-id');
    const countryCode = phoneInputEl.dataset.countryCode || '7';
    const phoneInput = phoneInputEl.value.trim();
    const cleanPhoneInput = phoneInput.replace(/\D/g, ''); 
    const loginId = countryCode + cleanPhoneInput;

    const errorEl = document.getElementById('error-message-phone');
    const nextBtn = document.getElementById('next-phone-btn');

    if (!cleanPhoneInput) {
        errorEl.textContent = 'Пожалуйста, введите номер телефона.';
        errorEl.style.display = 'block';
        return;
    }

    nextBtn.disabled = true;
    nextBtn.innerHTML = `<div class="button-spinner"></div> <span>Проверка...</span>`;
    errorEl.style.display = 'none';

    try {
        const phoneIndexRef = firebase.database().ref('phoneIndex/' + loginId);
        const phoneSnapshot = await phoneIndexRef.once('value');
        
        if (!phoneSnapshot.exists()) {
            throw new Error("Номер не найден в базе данных.");
        }

        window.currentLoginId = loginId;
        window.phoneData = phoneSnapshot.val();
        
        window.isLegacyOwner = (typeof window.phoneData === 'string');

        document.getElementById('step-phone').style.display = 'none';
        document.getElementById('step-password').style.display = 'block';

        const titleEl = document.getElementById('password-title');
        const confirmGroup = document.getElementById('confirm-password-group');
        const loginBtn = document.getElementById('login-btn');

        if (!window.isLegacyOwner && !window.phoneData.password) {
            window.isSettingPassword = true;
            titleEl.textContent = 'Установите пароль';
            confirmGroup.style.display = 'flex';
            loginBtn.innerHTML = '<span>Сохранить и войти</span>';
        } else {
            window.isSettingPassword = false;
            titleEl.textContent = 'Введите пароль';
            confirmGroup.style.display = 'none';
            loginBtn.innerHTML = '<span>Войти</span>';
        }

    } catch (error) {
        errorEl.textContent = error.message;
        errorEl.style.display = 'block';
    } finally {
        nextBtn.disabled = false;
        nextBtn.innerHTML = `<span>Далее</span>`;
    }
}

// ШАГ 2: Обработка пароля (Создание или Вход)
async function handlePasswordSubmit() {
    const password = document.getElementById('login-password').value;
    const confirmPassword = document.getElementById('login-password-confirm').value;
    const errorEl = document.getElementById('error-message-pwd');
    const loginBtn = document.getElementById('login-btn');
    const rememberMe = document.getElementById('remember-me').checked;

    if (!password) {
        errorEl.textContent = 'Пожалуйста, введите пароль.';
        errorEl.style.display = 'block';
        return;
    }

    if (window.isSettingPassword && password !== confirmPassword) {
        errorEl.textContent = 'Пароли не совпадают.';
        errorEl.style.display = 'block';
        return;
    }

    loginBtn.disabled = true;
    loginBtn.innerHTML = `<div class="button-spinner"></div> <span>Вход...</span>`;
    errorEl.style.display = 'none';

    try {
        if (window.isSettingPassword) {
            await firebase.database().ref('phoneIndex/' + window.currentLoginId + '/password').set(password);
            window.phoneData.password = password;
            window.isSettingPassword = false;
        } else if (!window.isLegacyOwner) {
            if (window.phoneData.password !== password) {
                throw new Error("Неверный пароль.");
            }
        }

        // Сохраняем введенный пароль для подтверждения сброса/установки ПИН-кода на следующих экранах
        window.enteredPassword = password;

        let pvzList = [];

        if (window.isLegacyOwner) {
            const uid = window.phoneData;
            const userRef = firebase.database().ref('users/' + uid);
            const userSnap = await userRef.once('value');
            const userData = userSnap.val();
            
            let email = null;
            if(userData && userData.email) email = userData.email;
            else if (userData && userData.pvzInfo && userData.pvzInfo.email) email = userData.pvzInfo.email;
            else if (userData && userData.pvzInfo && typeof userData.pvzInfo === 'object') {
                const firstPvz = Object.values(userData.pvzInfo)[0];
                if (firstPvz && firstPvz.email) email = firstPvz.email;
            }
            
            if (!email) throw new Error("Ошибка данных аккаунта. Email не найден.");
            
            const persistence = rememberMe ? firebase.auth.Auth.Persistence.LOCAL : firebase.auth.Auth.Persistence.SESSION;
            await firebase.auth().setPersistence(persistence);
            
            await firebase.auth().signInWithEmailAndPassword(email, password);
            
            if (userData.pvzInfo && typeof userData.pvzInfo === 'object') {
                if (Array.isArray(userData.pvzInfo)) pvzList = userData.pvzInfo;
                else if (userData.pvzInfo.pvzId) pvzList = [userData.pvzInfo]; 
                else pvzList = Object.values(userData.pvzInfo);
            }
        } else {
            if (window.phoneData.pvzs) {
                pvzList = Object.values(window.phoneData.pvzs);
            }

            if(rememberMe) {
                localStorage.setItem('employeePhone', window.currentLoginId);
            } else {
                sessionStorage.setItem('employeePhone', window.currentLoginId);
            }
        }

        showPvzSelectionScreen(pvzList);

    } catch (error) {
        errorEl.textContent = error.code === 'auth/wrong-password' ? 'Неверный пароль.' : (error.message || 'Ошибка входа.');
        errorEl.style.display = 'block';
    } finally {
        loginBtn.disabled = false;
        loginBtn.innerHTML = `<span>Войти</span>`;
    }
}

// ШАГ 3: Отображение пунктов выдачи
function showPvzSelectionScreen(pvzListRaw) {
    document.getElementById('main-auth-form').style.display = 'none';
    document.getElementById('manager-selection-screen').style.display = 'none';
    document.getElementById('pin-screen').style.display = 'none';
    
    const listContainer = document.getElementById('pvz-list-container');
    listContainer.innerHTML = '';

    let pvzList = [];
    if (pvzListRaw && typeof pvzListRaw === 'object') {
        if (Array.isArray(pvzListRaw)) pvzList = pvzListRaw;
        else if (pvzListRaw.pvzId) pvzList = [pvzListRaw]; 
        else pvzList = Object.values(pvzListRaw);
    }

    if (pvzList.length > 0) {
        pvzList.forEach(pvz => {
            const btn = document.createElement('div');
            btn.className = 'pvz-select-item';
            btn.innerHTML = `<div><strong>ID: ${pvz.pvzId || 'Не указан'}</strong><span style="color: var(--text-secondary-color); font-size: 0.9rem;">${pvz.address || 'Адрес не указан'}</span></div><i class="fas fa-chevron-right" style="color: var(--gray-medium);"></i>`;
            btn.addEventListener('click', () => selectPvzAndProceed(pvz));
            listContainer.appendChild(btn);
        });
    } else {
        listContainer.innerHTML = '<p style="text-align:center; padding: 20px;">ПВЗ не найдены.</p>';
    }
    
    document.getElementById('pvz-selection-screen').style.display = 'block';
}

// ШАГ 4: Выбор ПВЗ и переход к списку сотрудников
async function selectPvzAndProceed(selectedPvz) {
    if(selectedPvz.pvzId) {
        localStorage.setItem('savedPvzId', selectedPvz.pvzId);
    }
    
    document.getElementById('pvz-selection-screen').style.display = 'none';

    let ownerUid = selectedPvz.uid;
    if (!ownerUid && firebase.auth().currentUser) {
        ownerUid = firebase.auth().currentUser.uid;
    }

    if (!ownerUid) {
        alert("Системная ошибка: Не удалось определить владельца ПВЗ.");
        return;
    }
    
    // Сохраняем UID владельца для дальнейших быстрых входов
    localStorage.setItem('savedOwnerUid', ownerUid);
    const pvzId = selectedPvz.pvzId;

    loadEmployeesForFastLogin(ownerUid, pvzId);
}

// Функция для загрузки сотрудников (используется и при выборе ПВЗ, и при быстром входе)
async function loadEmployeesForFastLogin(ownerUid, pvzId) {
    const empRef = firebase.database().ref(`users/${ownerUid}/employees/${pvzId}`);
    const snap = await empRef.once('value');
    let employees = [];

    if (snap.exists()) {
        employees = Object.values(snap.val());
    } else {
        // Создаем дефолтного сотрудника, если пусто (Собственник)
        const defaultEmp = {
            id: Math.floor(100000000 + Math.random() * 900000000).toString(),
            lastName: 'Собственник',
            firstName: 'ПВЗ',
            patronymic: '',
            role: 'owner',
            phone: window.currentLoginId || ''
        };
        await empRef.child(defaultEmp.id).set(defaultEmp);
        employees.push(defaultEmp);
    }

    const list = document.querySelector('.manager-list');
    list.innerHTML = '';
    
    if (employees.length === 0) {
        list.innerHTML = '<p style="text-align:center; padding: 20px;">Сотрудники не найдены.</p>';
    }

    employees.forEach(emp => {
        const item = document.createElement('div');
        item.className = 'manager-item';
        item.innerHTML = `<strong>${emp.lastName} ${emp.firstName}</strong><span>${emp.role === 'owner' ? 'Собственник ПВЗ' : 'Менеджер'}</span>`;
        item.addEventListener('click', () => {
            handleEmployeeClick(emp, ownerUid, pvzId);
        });
        list.appendChild(item);
    });

    document.getElementById('pvz-selection-screen').style.display = 'none';
    document.getElementById('manager-selection-screen').style.display = 'block';
}

// ШАГ 5: Обработка клика по сотруднику (Логика первичной авторизации и ПИН-кода)
async function handleEmployeeClick(emp, ownerUid, pvzId) {
    let authEmps = JSON.parse(localStorage.getItem('authDeviceEmps') || '{}');
    let isAuthorized = authEmps[emp.id] === true;
    
    // Проверяем, совпадает ли введенный при текущем логине номер с номером сотрудника
    let phoneMatches = false;
    if (window.currentLoginId && emp.phone) {
        phoneMatches = window.currentLoginId === emp.phone;
    }

    // Если сотрудник еще не авторизован на этом устройстве И мы не зашли сейчас под его номером
    if (!isAuthorized && !phoneMatches) {
        // Требуется первичная авторизация!
        document.getElementById('manager-selection-screen').style.display = 'none';
        document.getElementById('main-auth-form').style.display = 'block';
        document.getElementById('step-password').style.display = 'none';
        document.getElementById('step-phone').style.display = 'block';

        const warningEl = document.getElementById('primary-auth-warning');
        warningEl.style.display = 'flex';
        
        // Очищаем контекст логина, чтобы заставить ввести номер
        window.currentLoginId = null;
        window.enteredPassword = null;
        return;
    }

    // Если проверку прошли - готовим экран ПИН-кода
    window.currentSelectedEmp = emp;
    window.currentOwnerUid = ownerUid;
    window.currentPvzId = pvzId;

    document.getElementById('manager-selection-screen').style.display = 'none';
    document.getElementById('pin-screen').style.display = 'block';

    const empRef = firebase.database().ref(`users/${ownerUid}/employees/${pvzId}/${emp.id}`);
    const snap = await empRef.once('value');
    const empData = snap.val();
    window.currentEmpPin = empData.pin || null;

    const pinTitle = document.getElementById('pin-title');
    const pinInput = document.getElementById('pin-input');
    const accPwdGroup = document.getElementById('pin-account-pwd-group');
    const forgotLink = document.getElementById('forgot-pin-link');
    const pinError = document.getElementById('pin-error-message');

    pinInput.value = '';
    if(document.getElementById('pin-confirm-password')) document.getElementById('pin-confirm-password').value = '';
    pinError.style.display = 'none';

    if (window.resettingPinForEmpId === emp.id) {
        // Установка НОВОГО пин кода после нажатия "Не помню"
        pinTitle.textContent = 'Установите новый пин код';
        accPwdGroup.style.display = 'block';
        forgotLink.style.display = 'none';
        document.getElementById('pin-submit-btn').innerHTML = '<span>Сохранить и войти</span>';
        window.pinMode = 'reset';
    } else if (!window.currentEmpPin) {
        // Установка пин кода ПЕРВЫЙ РАЗ
        pinTitle.textContent = 'Установите пин код';
        accPwdGroup.style.display = 'block';
        forgotLink.style.display = 'none';
        document.getElementById('pin-submit-btn').innerHTML = '<span>Сохранить и войти</span>';
        window.pinMode = 'setup';
    } else {
        // Стандартный вход
        pinTitle.textContent = 'Введите пин код';
        accPwdGroup.style.display = 'none';
        forgotLink.style.display = 'block';
        document.getElementById('pin-submit-btn').innerHTML = '<span>Войти</span>';
        window.pinMode = 'enter';
    }
}

// Забыли ПИН-код: возврат в начало (Шаг 1)
function handleForgotPin() {
    window.resettingPinForEmpId = window.currentSelectedEmp.id;
    document.getElementById('pin-screen').style.display = 'none';
    document.getElementById('main-auth-form').style.display = 'block';
    document.getElementById('step-password').style.display = 'none';
    document.getElementById('step-phone').style.display = 'block';

    // Скрываем желтое уведомление, если оно висело
    document.getElementById('primary-auth-warning').style.display = 'none';

    // Подставляем номер сотрудника
    const phoneInput = document.getElementById('login-id');
    if (window.currentSelectedEmp.phone) {
        const cleanPhone = window.currentSelectedEmp.phone.replace(/\D/g, '').slice(-10);
        phoneInput.value = cleanPhone;
    }
}

// Отправка/Проверка ПИН-кода
async function submitPin() {
    const pin = document.getElementById('pin-input').value;
    const pwd = document.getElementById('pin-confirm-password').value;
    const errorEl = document.getElementById('pin-error-message');
    const submitBtn = document.getElementById('pin-submit-btn');

    if (!pin || pin.length > 5) {
        errorEl.textContent = 'Пин код должен содержать до 5 цифр.';
        errorEl.style.display = 'block';
        return;
    }

    errorEl.style.display = 'none';
    submitBtn.disabled = true;
    submitBtn.innerHTML = `<div class="button-spinner"></div>`;

    try {
        if (window.pinMode === 'setup' || window.pinMode === 'reset') {
            if (!pwd) {
                throw new Error('Введите пароль от аккаунта для подтверждения.');
            }
            // Проверяем пароль, который ввели на 2 шаге авторизации
            if (pwd !== window.enteredPassword) {
                throw new Error('Неверный пароль от аккаунта.');
            }

            // Сохраняем новый ПИН в БД
            const empRef = firebase.database().ref(`users/${window.currentOwnerUid}/employees/${window.currentPvzId}/${window.currentSelectedEmp.id}`);
            await empRef.child('pin').set(pin);
            window.currentEmpPin = pin;
            
            // Сбрасываем флаг восстановления
            window.resettingPinForEmpId = null;

        } else if (window.pinMode === 'enter') {
            if (pin !== window.currentEmpPin) {
                throw new Error('Неверный пин код.');
            }
        }

        // Авторизуем устройство для этого сотрудника навсегда
        let authEmps = JSON.parse(localStorage.getItem('authDeviceEmps') || '{}');
        authEmps[window.currentSelectedEmp.id] = true;
        localStorage.setItem('authDeviceEmps', JSON.stringify(authEmps));

        // Выполняем вход в рабочую область
        sessionStorage.setItem('currentManager', `${window.currentSelectedEmp.firstName} ${window.currentSelectedEmp.lastName}`);
        sessionStorage.setItem('currentManagerId', window.currentSelectedEmp.id);
        sessionStorage.setItem('currentManagerRole', window.currentSelectedEmp.role);
        sessionStorage.setItem('showServerLoading', 'true');
        
        window.location.href = 'index.html';

    } catch (e) {
        errorEl.textContent = e.message;
        errorEl.style.display = 'block';
    } finally {
        submitBtn.disabled = false;
        submitBtn.innerHTML = window.pinMode === 'enter' ? `<span>Войти</span>` : `<span>Сохранить и войти</span>`;
    }
}

// Восстановление пароля (Существующая логика)
let recoveryTargetEmail = '';

async function handleCheckRecoveryEmail() {
    const email = document.getElementById('recovery-email').value.trim();
    const errorEl = document.getElementById('recovery-error-message');
    const btn = document.getElementById('check-recovery-email-btn');
    
    if (!email) { errorEl.textContent = 'Введите Email.'; errorEl.style.display = 'block'; return; }
    errorEl.style.display = 'none'; 
    btn.disabled = true;

    try {
        const usersRef = firebase.database().ref('users');
        const snapshot = await usersRef.orderByChild('email').equalTo(email).once('value');
        
        if (snapshot.exists()) {
            const usersData = snapshot.val();
            const uid = Object.keys(usersData)[0];
            const userData = usersData[uid];
            
            let address = 'Адрес скрыт или не указан';
            if(userData.pvzInfo && userData.pvzInfo.address) address = userData.pvzInfo.address;
            
            recoveryTargetEmail = email;
            
            document.getElementById('recovery-step1').style.display = 'none';
            document.getElementById('recovery-step2').style.display = 'block';
            document.getElementById('recovery-pvz-address').textContent = address;
        } else {
            errorEl.textContent = 'Пользователь с таким Email не найден.'; 
            errorEl.style.display = 'block';
        }
    } catch (error) {
        errorEl.textContent = 'Ошибка проверки базы данных.'; 
        errorEl.style.display = 'block';
        console.error(error);
    } finally { 
        btn.disabled = false; 
    }
}

async function sendRecoveryLink() {
    if(!recoveryTargetEmail) return;
    try {
        await firebase.auth().sendPasswordResetEmail(recoveryTargetEmail);
        toggleModal('recovery-modal', false);
        alert('На указанную почту отправлено письмо с указаниями на восстановление пароля. Не забудьте также проверить папку "Спам" в вашем почтовом клиенте!');
    } catch (e) {
        alert('Ошибка при отправке письма: ' + e.message);
    }
}

// Регистрация
function setupRegisterLogic() {
    document.getElementById('next-btn-step1').addEventListener('click', () => {
        const phone = document.getElementById('reg-phone').value.trim();
        const pass = document.getElementById('reg-password').value;
        const err = document.getElementById('error-message-step1');
        
        if (phone.length < 7 || pass.length < 8) {
            err.textContent = 'Проверьте корректность данных';
            err.style.display = 'block';
            return;
        }
        err.style.display = 'none';
        document.getElementById('step1').classList.remove('active');
        document.getElementById('step2').classList.add('active');
    });

    document.getElementById('next-btn-step2').addEventListener('click', () => {
        const address = document.getElementById('reg-address').value.trim();
        const fittingRooms = document.getElementById('reg-fitting-rooms').value;
        const workHours = document.getElementById('reg-work-hours').value.trim();
        const errorStep2 = document.getElementById('error-message-step2');

        if (!address || !fittingRooms || !workHours) {
            errorStep2.textContent = 'Заполните все поля о ПВЗ'; 
            errorStep2.style.display = 'block'; 
            return;
        }
        errorStep2.style.display = 'none';
        document.getElementById('step2').classList.remove('active');
        document.getElementById('step3').classList.add('active');
    });

    document.getElementById('register-btn').addEventListener('click', handleRegister);
}

async function handleRegister() {
    const loginPhoneEl = document.getElementById('reg-phone');
    const loginCountryCode = loginPhoneEl.dataset.countryCode || '7';
    const loginPhoneClean = loginPhoneEl.value.replace(/\D/g, '');
    const loginIdFull = loginCountryCode + loginPhoneClean;
    const password = document.getElementById('reg-password').value;

    const address = document.getElementById('reg-address').value.trim();
    const fittingRooms = document.getElementById('reg-fitting-rooms').value;
    const workHours = document.getElementById('reg-work-hours').value.trim();
    
    const lName = document.getElementById('owner-last-name').value.trim();
    const fName = document.getElementById('owner-first-name').value.trim();
    const pName = document.getElementById('owner-patronymic').value.trim();
    const dob = document.getElementById('owner-dob').value;
    const email = document.getElementById('owner-email').value.trim();
    
    const ownerPhoneEl = document.getElementById('owner-phone');
    const ownerCountryCode = ownerPhoneEl.dataset.countryCode || '7';
    const ownerPhoneClean = ownerPhoneEl.value.replace(/\D/g, '');
    const ownerPhoneFull = ownerCountryCode + ownerPhoneClean;

    const errorStep3 = document.getElementById('error-message-step3');

    if (!lName || !fName || !dob || !email || !ownerPhoneClean) {
        errorStep3.textContent = 'Заполните все обязательные поля'; 
        errorStep3.style.display = 'block'; 
        return;
    }

    document.getElementById('step3').classList.remove('active');
    document.getElementById('step-loading').classList.add('active');

    try {
        const phoneRef = firebase.database().ref('phoneIndex/' + loginIdFull);
        const snap = await phoneRef.once('value');
        if (snap.exists()) throw new Error("Этот номер для ПВЗ уже зарегистрирован.");

        const userCred = await firebase.auth().createUserWithEmailAndPassword(email, password);
        const uid = userCred.user.uid;

        const pvzId = Math.floor(100000 + Math.random() * 900000).toString();
        const empId = Math.floor(100000000 + Math.random() * 900000000).toString(); 

        const pvzInfo = { pvzId, address, fittingRooms, workHours, email, phone: loginIdFull, employeeId: empId, uid: uid };

        await firebase.database().ref('users/' + uid).set({
            phone: loginIdFull, 
            email: email, 
            pvzInfo: pvzInfo, 
            data: {}
        });

        await firebase.database().ref(`users/${uid}/employees/${pvzId}/${empId}`).set({
            id: empId, 
            lastName: lName, 
            firstName: fName, 
            patronymic: pName, 
            dob: dob,
            role: 'owner', 
            phone: ownerPhoneFull, 
            email: email
        });

        await phoneRef.set(uid);

        document.getElementById('step-loading').classList.remove('active');
        document.getElementById('step-success').classList.add('active');

        document.getElementById('new-login-id').textContent = loginIdFull;
        document.getElementById('new-login-password').textContent = password;
        document.getElementById('new-pvz-id').textContent = pvzId;

        await firebase.auth().signOut(); 
    } catch (error) {
        document.getElementById('step-loading').classList.remove('active');
        document.getElementById('step3').classList.add('active');
        errorStep3.textContent = error.message; 
        errorStep3.style.display = 'block';
    }
}

function toggleModal(modalId, show) {
    const modal = document.getElementById(modalId);
    if (!modal) return;
    if (show) { modal.style.display = 'flex'; setTimeout(() => modal.classList.add('visible'), 10); } 
    else { modal.classList.remove('visible'); setTimeout(() => { modal.style.display = 'none'; }, 300); }
}